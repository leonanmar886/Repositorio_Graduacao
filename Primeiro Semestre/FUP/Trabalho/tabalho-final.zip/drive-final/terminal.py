import funcoes

funcaoDesejada = funcoes.MostrarMenu()
funcoes.ChamarFuncao(funcaoDesejada)

